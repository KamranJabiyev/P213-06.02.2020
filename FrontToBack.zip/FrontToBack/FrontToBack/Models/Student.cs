﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FrontToBack.Models
{
    public class Student
    {
        public int Id { get; set; }
        [Required(ErrorMessage ="Qaqa bu teleb olunur eee"),StringLength(50,ErrorMessage ="50-ni ashma qadan alim")]
        public string Name { get; set; }
        [StringLength(50, ErrorMessage = "50-ni ashma qadan alim")]
        public string Surname { get; set; }
        [StringLength(500, ErrorMessage = "500-ni ashma qadan alim"),MinLength(20,ErrorMessage ="20 simvol olmalidi minimum")]
        public string Description { get; set; }
    }
}
