﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FrontToBack.Models
{
    public class About
    {
        public int Id { get; set; }
        [Required,StringLength(255)]
        public string Image { get; set; }
        [StringLength(255)]
        public string Link { get; set; }

        [Required, StringLength(100)]
        public string Title { get; set; }

        [Required, StringLength(455)]
        public string Description { get; set; }

        [StringLength(155)]
        public string Info1 { get; set; }

        [StringLength(155)]
        public string Info2 { get; set; }

        [StringLength(155)]
        public string Info3 { get; set; }

    }
}
