﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontToBack.DAL;
using FrontToBack.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace FrontToBack.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _db;
        public HomeController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            HomeVM home = new HomeVM
            {
                Sliders=_db.Sliders,
                SliderText=_db.SliderTexts.First(s=>s.Id==1),
                Categories=_db.Categories,
                Products=_db.Products.Take(8),
                Abouts=_db.Abouts.First(a=>a.Id==1)
            };
            return View(home);
        }
    }
}