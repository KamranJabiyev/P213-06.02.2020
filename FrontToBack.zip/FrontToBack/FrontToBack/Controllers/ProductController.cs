﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontToBack.DAL;
using FrontToBack.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace FrontToBack.Controllers
{
    public class ProductController : Controller
    {
        private readonly AppDbContext _db;

        public ProductController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            ViewBag.Count = _db.Products.Count();
            return View(_db.Products.Select(p=>new ProductVM { 
                Id=p.Id,
                Name=p.Name,
                Price=p.Price,
                Image=p.Image,
                Category=p.Category
            }).Take(4));
        }

        public IActionResult LoadMore(int skip)
        {
            //return Content(skip.ToString()+name);
            var model = _db.Products.Select(p => new ProductVM
            {
                Id = p.Id,
                Name = p.Name,
                Price = p.Price,
                Image = p.Image,
                Category = p.Category
            }).Skip(skip).Take(4);

            return PartialView("_ProductPartial", model);
            //OLD VERSION
            //return Json(new { 
            //    data= _db.Products.Select(p => new ProductVM
            //    {
            //        Id = p.Id,
            //        Name = p.Name,
            //        Price = p.Price,
            //        Image = p.Image,
            //        Category = p.Category
            //    }).Skip(4).Take(4)
            //});
        }
    }
}